﻿/// <reference types="vite/client" />
